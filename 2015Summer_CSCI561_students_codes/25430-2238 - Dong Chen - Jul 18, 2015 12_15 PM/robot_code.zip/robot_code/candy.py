
from Myro import *
init("/dev/tty.Fluke2-0236-Fluke2")

# We also need to import the graphics library!
from Graphics import *

# Print the current battery level
print("Battery level:", getBattery())

print('Drawing a candy')

#half circle d=5
#motors(-0.2,0.4,4.2)


motors(0.4,-0.2,4.2)

turnBy(120)
forward(0.5, 0.33) #4cm
turnBy(-120)
forward(0.5, 0.33) #4cm
turnBy(-120)
forward(0.5, 0.33) #4cm
turnBy(120)
motors(0.4,-0.2,4.2)
turnBy(60)
forward(0.5, 0.33) #4cm
turnBy(120)
forward(0.5, 0.33) #4cm
turnBy(120)
forward(0.5, 0.33) #4cm
stop()





