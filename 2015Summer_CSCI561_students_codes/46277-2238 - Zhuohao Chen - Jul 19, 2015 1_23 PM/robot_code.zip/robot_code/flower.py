from Myro import *
init("/dev/tty.Fluke2-0240-Fluke2")

# We also need to import the graphics library!
from Graphics import *

# Print the current battery level
print("Battery level:", getBattery())

print('Drawing a flower')

#total circle d=8
#motors(-0.2,0.68,5.8)

#total circle d=4
#motors(-0.2,0.35,9.6)
#half circle d=4
#motors(-0.2,0.35,4.8)

#left first
motors(-0.2,0.68,5.8)
turnBy(-60)

motors(-0.2,0.35,4.6)
turnBy(-120)
motors(-0.2,0.35,4.6)
turnBy(-120)
motors(-0.2,0.35,4.6)
turnBy(-120)
motors(-0.2,0.35,4.6)
turnBy(-120)
motors(-0.2,0.35,4.6)
turnBy(-120)
motors(-0.2,0.35,4.6)


stop()


