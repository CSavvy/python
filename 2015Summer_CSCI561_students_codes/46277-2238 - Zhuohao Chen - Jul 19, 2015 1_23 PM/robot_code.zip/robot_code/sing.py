from Myro import *
init("/dev/tty.Fluke2-0240-Fluke2") #enter your port number

#assign variable names to frequencies for easier programming
C3 = 261.63
E3 = 329.63
F3 = 349.23
C4 = 523.25
D4 = 587.33
E4 = 659.26
F4 = 698.46
G4 = 783.99
A4 = 880
B4 = 987.77
C5 = 1046.5
D5 = 1174.66
E5 = 1318.51
F5 = 1396.91
G5 = 1567.98


beep(0.96,E5)
beep(0.96,A4)
beep(0.16,C5)
beep(0.16,D5)
beep(0.64,E5)
beep(0.64,A4)
beep(0.16,C5)
beep(0.16,D5)
beep(1.92,B4)
wait(0.96)

beep(0.96,D5)
beep(0.96,G4)
beep(0.16,C5)
beep(0.16,B4)
beep(0.64,D5)
beep(0.64,G4)
beep(0.16,C5)
beep(0.16,B4)
beep(1.92,A4)
wait(0.96)

beep(0.96,E5)
beep(0.96,A4)
beep(0.16,C5)
beep(0.16,D5)
beep(0.64,E5)
beep(0.64,A4)
beep(0.16,C5)
beep(0.16,D5)
beep(1.92,B4)
wait(0.96)

beep(0.96,D5)
beep(0.96,G4)
beep(0.16,C5)
beep(0.16,B4)
beep(0.64,D5)
beep(0.96,G4)
beep(0.16,C5)
beep(0.16,B4)
beep(1.68,A4)
wait(0.96)