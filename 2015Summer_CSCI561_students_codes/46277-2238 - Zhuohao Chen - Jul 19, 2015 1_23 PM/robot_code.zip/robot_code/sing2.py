from Myro import *
init() #enter your port number

#assign variable names to frequencies for easier programming
C3 = 261.63
E3 = 329.63
F3 = 349.23
C4 = 523.25
D4 = 587.33
E4 = 659.26
F4 = 698.46
G4 = 783.99
A4 = 880
B4 = 987.77
C5 = 1046.5
D5 = 1174.66
E5 = 1318.51
F5 = 1396.91
G5 = 1567.98


beep(0.32,E5)
beep(0.16,D5)
beep(0.16,C5)
beep(0.32,C5)
beep(0.32,C5)
beep(0.32,C5)
beep(0.32,C5)
beep(0.16,C5)
beep(0.32,C5)
beep(0.16,C5)
beep(0.32,C5)
beep(0.16,C5)
beep(0.16,B4)
beep(0.16,C5)
beep(0.16,B4)
beep(0.32,B4)
beep(0.64,B4)
wait(0.32)

beep(0.32,E5)
beep(0.16,D5)
beep(0.16,C5)
beep(0.32,C5)
beep(0.16,C5)
beep(0.16,A4)
beep(0.16,C5)
beep(0.16,A4)
beep(0.32,C5)
beep(0.16,A4)
beep(0.32,C5)
beep(0.48,A4)
beep(0.32,C5)
beep(0.16,A4)
beep(0.32,C5)
beep(0.32,D5)
beep(0.64,D5)
wait(0.32)

beep(0.32,E5)
beep(0.16,D5)
beep(0.16,C5)
beep(0.32,C5)
beep(0.16,C5)
beep(0.16,A4)
beep(0.16,C5)
beep(0.16,A4)
beep(0.32,C5)
beep(0.16,A4)
beep(0.32,C5)
beep(0.48,A4)
beep(0.32,C5)
beep(0.16,A4)
beep(0.32,D5)
beep(0.16,C5)
beep(0.16,D5)
beep(0.16,C5)
beep(0.32,D5)
beep(0.16,C5)
beep(0.32,E5)
beep(0.16,D5)
beep(0.32,D5)

beep(0.16,C5)
beep(0.16,D5)
beep(0.16,C5)
beep(0.32,E5)
beep(0.16,F5)
beep(0.16,E5)
beep(0.16,D5)
beep(0.16,C5)
beep(0.48,A4)
wait(0.64)

beep(0.32,C5)
beep(0.32,C5)
beep(0.16,C5)
beep(0.08,C5)
beep(0.72,B4)
wait(0.64)






