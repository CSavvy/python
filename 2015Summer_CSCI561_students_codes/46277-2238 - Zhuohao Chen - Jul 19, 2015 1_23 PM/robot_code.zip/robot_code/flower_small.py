from Myro import *
init("/dev/tty.Fluke2-0240-Fluke2")

# We also need to import the graphics library!
from Graphics import *

# Print the current battery level
print("Battery level:", getBattery())

print('Drawing a flower')

#half circle d=3
#motors(-0.2,0.305,5.6)

#left first

#total circle d=6
#motors(-0.2,0.47,7.5)
turnBy(-60)
motors(-0.2,0.28,5.55)
turnBy(-120)
motors(-0.2,0.28,5.55)
turnBy(-120)
motors(-0.2,0.28,5.55)
turnBy(-120)
motors(-0.2,0.28,5.55)
turnBy(-120)
motors(-0.2,0.28,5.55)
turnBy(-120)
motors(-0.2,0.28,4)


stop()