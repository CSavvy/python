from Myro import *
init("/dev/tty.Fluke2-0236-Fluke2")

# We also need to import the graphics library!
from Graphics import *

# Print the current battery level
print("Battery level:", getBattery())

print('Drawing a T-shirt')

motors(-0.2,0.4,4.2)
turnBy(-90)
forward(0.5, 0.167) #2cm
turnBy(-45)
forward(0.5, 0.33) #4cm
turnBy(-90)
forward(0.5, 0.167) #2cm
turnBy(-90)
forward(0.5, 0.167) #2cm
turnBy(135)
forward(0.5, 1) #12cm
turnBy(-90)
forward(0.5, 0.75) #9cm
turnBy(-90)
forward(0.5, 1) #12cm
turnBy(135)
forward(0.5, 0.167) #2cm
turnBy(-90)
forward(0.5, 0.167) #2cm
turnBy(-90)
forward(0.5, 0.33) #4cm
turnBy(-45)
forward(0.5, 0.167) #2cm
stop()





