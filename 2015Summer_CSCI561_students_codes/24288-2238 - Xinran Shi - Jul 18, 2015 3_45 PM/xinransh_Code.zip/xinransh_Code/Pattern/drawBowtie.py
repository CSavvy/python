from Myro import *
init("/dev/tty.Fluke2-01D2-Fluke2")

def circle(angle = 360):
    circleTime = 11.5
    motors(0.3, -0.2, (angle / 360) * circleTime)

def drawHalf():
    angle = 60
    length = 0.5
    length2 = 0.5
    speed = 0.5
    turnBy(angle)
    forward(speed, length / speed)
    turnBy(180 - angle)
    forward(speed, length2 / speed)
    turnBy(180 - angle)
    forward(speed, length / speed)
    turnBy(angle)

def drawBowtie():
    drawHalf()
    circle(540)
    drawHalf()

drawBowtie()
