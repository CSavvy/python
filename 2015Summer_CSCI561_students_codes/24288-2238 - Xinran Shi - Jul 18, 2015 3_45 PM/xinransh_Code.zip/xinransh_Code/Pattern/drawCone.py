from Myro import *
init("/dev/tty.Fluke2-01D2-Fluke2")

def circle(angle = 360):
    circleTime = 7.5
    motors(0.5, -0.2, (angle / 360) * circleTime)

def drawCone():
    angle = 25
    length = 0.7
    turnBy(angle)
    forward(1, length)
    turnBy(-angle)
    circle(540)
    turnBy(-angle)
    forward(1, length)

#main
drawCone()
