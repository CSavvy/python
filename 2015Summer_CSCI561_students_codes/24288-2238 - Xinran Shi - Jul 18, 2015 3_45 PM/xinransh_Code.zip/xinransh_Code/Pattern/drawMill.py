from Myro import *
init("/dev/tty.Fluke2-01D2-Fluke2")

def piece():
    f = 0.3
    a = f * (3**(0.5))
    b = f
    c = 2 * f
    speed = 0.5

    forward(speed, a / speed)
    turnBy(90)
    forward(speed, b / speed)
    turnBy(120)
    forward(speed, c / speed)
    turnBy(60)


def drawMill():
    forward(0.5, 1.5)
    turnBy(30)
    piece()
    piece()
    piece()
    piece()


drawMill()
