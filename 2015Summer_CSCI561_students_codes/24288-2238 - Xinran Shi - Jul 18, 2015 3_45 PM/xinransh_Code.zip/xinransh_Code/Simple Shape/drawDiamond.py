from Myro import *
init("/dev/tty.Fluke2-01D2-Fluke2")


# turnBy(20)
# forward(1,0.5)
# turnBy(-40)
# forward(1,0.5)
# turnBy(-140)
# forward(1,0.5)
# turnBy(-40)
# forward(1,0.5)

def drawDiamond(angle, length):
    turnBy(angle)
    forward(1, length)
    turnBy(- 2 * angle)
    forward(1, length)
    turnBy(- 180 + 2 * angle)
    forward(1,0.5)
    turnBy(- 2 * angle)
    forward(1, length)


# main
drawDiamond(20, 0.5)
