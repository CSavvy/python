from Myro import *
init("/dev/tty.Fluke2-01D2-Fluke2")

length = 0.4
forward(0.5,0.4)
turnBy(120)
forward(0.5,0.4)
turnBy(120)
forward(0.5,0.4)
turnBy(120)
