from Myro import *
init("/dev/tty.Fluke2-01D2-Fluke2")


circleTime = 11.5
motors(0.3, -0.2, circleTime)
